<?php

namespace App\Http\Controllers;

use App\Mail\NewUserEmail;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;

class UserController extends Controller
{
    private $success = false;
    private $message = '';

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function settings(Request $request)
    {
        $title = 'update account setting';
        if ($request->method() == 'POST') {
            $data = $request->all();
            unset($data['_token']);
            $user = User::find(loginId());
            if (!empty($user)) {
                $profileImage = $user->image;
                if ($request->hasFile('file')) {
                    if (isset($user->image) && !empty($user->image)) {
                        $Path = public_path('images/profile') . $user->image;
                        if (file_exists($Path)) {
                            unlink($Path);
                        }
                    }
                    $profileImage = uploadImage($request, 'images/profile');
                }
                $data['image'] = $profileImage;
                $data['date_of_birth'] = databaseDateTimeFromat($data['date_of_birth']);
                $user->update($data);
                $this->success = true;
                $this->message = 'Profile updated successfully';
            }
            $arr = [];
            $arr['title'] = loginUserName().' '.$title;
            $arr['status'] = $this->success == true ? 'Successful' : 'Unsuccessful';
            $arr['created_at'] = now();
            $arr['updated_at'] = now();
            activity($arr);

            return response()->json(['success' => $this->success, 'message' => $this->message]);
        }
        return view('setting.index');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('users.index');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('users.create');
    }

    /**
     * This is used to update login user profile
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(Request $request)
    {
        $data = $request->all();
        $isAllow = 0;
        $isUser = false;
        $user = $email = '';
        $data['user_type'] = 2;
        $title = 'create a new user';
        unset($data['_token']);
        if (!empty($data['id'])) {
            $isUser = true;
            $user = User::find($data['id']);
        } else {
            $email = User::where('email', $data['email'])->first();
        }
        if (isCompany() == true) {
            $isAllow = User::where('created_by', loginId())->count();
        }
        if ($isAllow == 3) {
            $this->message = 'You can not create more than 3 users.';
        } else {
            if (empty($email)) {
                $isUser = true;
            } else {
                $this->message = 'User already exist';
            }
            if ($isUser == true) {
                $data['user_type'] = 2;
                if (isAdmin() == true) {
                    $data['user_type'] = 1;
                }
                $data['name'] = $data['first_name'] . ' ' . $data['last_name'];
                $data['created_by'] = loginId();
                $password = $data['password'];
                $data['password'] = Hash::make($data['password']);
                $data['company_logo'] = uploadImage($request, 'images/company');
                $data['created_at'] = currentDateTime();
                $data['updated_at'] = currentDateTime();
                unset($data['file']);
                if (!empty($data['id'])) {
                    unset($data['id']);
                    $user->update($data);
                    $this->message = 'User Updated successfully';
                    $title = 'updated a user';
                } else {
                    unset($data['id']);
                    User::insert($data);
                    Mail::to($data['email'])->send(new NewUserEmail($data, $password));
                    $this->message = 'User Created successfully';
                }
                $this->success = true;
            }
            $arr = [];
            $arr['title'] = loginUserName().' '.$title.' '.$data['first_name'] . ' ' . $data['last_name'];
            $arr['status'] = $this->success == true ? 'Successful' : 'Unsuccessful';
            $arr['created_at'] = now();
            $arr['updated_at'] = now();
            activity($arr);
        }

        return response()->json(['success' => $this->success, 'message' => $this->message]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user = User::find($id);

        return view('users.create', compact('user', 'id'));
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function suspend($id)
    {
        $title = 'suspend user';
        $name = '';
        if ($id) {
            $user =  User::find($id);
            $user->update(['is_suspend' => 1]);
            $this->message = 'User Suspended successfully';
            $this->success = true;
            $name = $user->name;

        }
        $arr = [];
        $arr['title'] = loginUserName().' '.$title. ' '. $name;
        $arr['status'] = $this->success == true ? 'Successful' : 'Unsuccessful';
        $arr['created_at'] = now();
        $arr['updated_at'] = now();
        activity($arr);

        return response()->json(['success' => $this->success, 'message' => $this->message]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function getUsers(Request $request)
    {
        $data = [];
        $pager = '';
        $page = $request->input('page');
        $perPage = $request->input('per_page');
        $users = User::select('id', 'name', 'company_name', 'phone', 'email',
            'created_at')
            ->orderBy('created_at', 'desc')
            ->where('is_suspend', 0)
            ->where('id', '<>', loginId());
        if (isCompany()) {
            $users->where('created_by', loginId());
        }
        if (!empty($users)) {
            $users = $users->get()->toArray();
            foreach ($users as $key => $row) {
                $users[$key]['created_at'] = viewDateFormat($row['created_at']);
            }
            $data = makePagination($users, $perPage, $page);
            $pager = paginationView($data, count($users));
        }

        return response()->json(['data' => $data, 'pager' => $pager]);
    }
}
