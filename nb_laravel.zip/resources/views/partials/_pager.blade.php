<div class="mypagination">

    {!! $info !!}

    <div class="notific-review-pages">
        <nav aria-label="Page navigation example">
            {!! $data->links('pagination::bootstrap-4') !!}
            <div class="clr-fix"></div>
        </nav>
    </div>
</div>
